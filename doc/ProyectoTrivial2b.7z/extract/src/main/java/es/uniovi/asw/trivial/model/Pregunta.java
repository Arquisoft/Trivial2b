package es.uniovi.asw.trivial.model;

public interface Pregunta {

	String toStringDebug();

	String[] getContestacion();
	
	int getCorrecta();
}
