package es.uniovi.asw.trivial.mainToMondoDB;

import es.uniovi.asw.trivial.persistence.Connection;


public class Main {

	public static void main(String[] args) {
		new Connection().connection();
	}
}
